The algorithm was tested 4 times on a specific string od length = 1000 alphanumeric characters (inputString.txt of every test folder)
and testOutput.txt holds the output of the /usr/bin/time -v ./main.cpp command.

OS and hardware configuration is shown in the main TEST folder.
