The algorithm was tested 4 times on the same string od length = 1000000 characters (inputString.txt of every test folder)
and testOutput.txt holds the output of  '/usr/bin/time -v ./main.cpp' and a bash script for a more precise time:

ts=$(date +%s%N) ; my_command ; tt=$((($(date +%s%N) - $ts)/1000000)) ; echo "Time taken: $tt"

OS and hardware configuration is shown in the main TEST folder.
